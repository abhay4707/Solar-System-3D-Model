import { createApp } from 'vue'
import App from './App.vue'
import './sass/main.scss';

createApp(App).mount('#app')